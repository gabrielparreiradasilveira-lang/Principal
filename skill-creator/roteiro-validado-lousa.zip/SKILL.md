---
name: roteiro-validado-lousa
description: Audita, valida e aprimora rascunhos ou roteiros de aula do mercado financeiro, preenchendo lacunas explicativas com informacoes tecnicas, exemplos praticos, falas de locucao e analogias visuais para transformar o material em roteiros completos em 5 blocos para gravacao com lousa digital (Wacom One e Goodnotes), encerrando com classificacao de nivel de adequacao e aprendizado. Use quando o usuario pedir para validar, revisar, enriquecer ou transformar um resumo, regra normativa ou roteiro incompleto em aula para certificacoes ANBIMA (CPA, C-PRO R, C-PRO I, CEA, CFG, CGA, CGE).
---
# Roteiro Validado Lousa

Valida rigorosamente premissas tecnicas, tributarias e regulatorias do mercado financeiro, aprimora rascunhos incompletos ou superficiais inserindo explicacoes completas, exemplos praticos, falas e analogias, e converte o conteudo auditado em um roteiro de aula enxuto, linear e neurocompativel em 5 blocos, pronto para locucao direta e anotacao em lousa digital (Wacom One / Goodnotes), com classificacao final de nivel de adequacao e aprendizado.

## When to Use

  - O usuario envia um rascunho tecnico, resumo normativo, tabela de aliquotas/prazos ou roteiro preliminar e pede para validar, melhorar e transformar em aula.
  - O usuario solicita uma aula direta ("Quero aula", "Gere o roteiro de gravacao") a partir de um topico ja discutido na conversa.
  - Explicacao de regras tributarias, cambiais, operacionais ou regulatorias (CMN, BCB, CVM, ANBIMA, Receita Federal) que exigem diferenciacao clara entre regra geral, excecoes e armadilhas de prova.
  - Producao de videoaulas dinamicas guiadas por raciocinio linear na lousa digital, sem depender de apresentacoes longas de slides.

## Steps

### Etapa 1: Auditoria Tecnica, Regulatoria e Diagnostico Pedagogico

Antes de redigir a aula, processe, valide e diagnostique o material do tema seguindo cinco verificacoes:

1.  **Base Normativa e Vigencia:** Confirme o ato normativo aplicavel (Decretos, Resolucoes CMN/CVM, Circulares BCB, Codigos ANBIMA ou jurisprudencia vinculante) na data de corte atual, descartando regras revogadas ou tabelas defasadas.
2.  **Mapeamento de Parametros Exatos:** Isole numeros criticos (aliquotas, prazos em dias uteis ou corridos, limites operacionais e percentuais de enquadramento) e associe cada numero exclusivamente a sua finalidade ou condicao de aplicacao.
3.  **Identificacao do Fato Gerador e Responsabilidade:** Defina com precisao cirurgica quando a obrigacao ou evento financeiro nasce (ex: liquidacao, resgate, come-cotas, contratacao), quem retem/recolhe e o que nao gera cobranca (ex: estoque ou saldo parado).
4.  **Isolamento do Ponto Cego (Pegadinha Central):** Identifique a confusao conceitual mais explorada pelas bancas (Cesgranrio e ANBIMA) - geralmente quando duas operacoes parecem iguais na forma (ex: mesma titularidade, mesmo prazo), mas possuem tratamentos distintos pela finalidade ou natureza.
5.  **Diagnostico de Completude e Profundidade Didatica:** Avalie se o texto ou rascunho enviado apresenta lacunas explicativas, passagens superficiais, falta de contexto pratico ou ausencia/fraqueza de analogias. Sempre que identificar explicacoes insuficientes, intervenha ativamente alterando e expandindo o texto: insira informacoes tecnicas complementares, exemplos reais de mercado, falas completas de locucao e analogias visuais para garantir o aprendizado integral.

Caso o usuario tenha enviado um rascunho previo, inicie a resposta apontando o que esta tecnicamente exato, corrigindo eventuais imprecisoes normativas e indicando quais lacunas didaticas serao enriquecidas no roteiro.

### Etapa 2: Filtragem Neurocompativel e Aprimoramento Textual

Traduza e expanda os elementos validados na Etapa 1 para uma comunicacao linear, completa e de baixa carga cognitiva:

  - **Reescrita e Enriquecimento Ativo:** Nao mantenha frases telegraficas ou topicos soltos que deixem duvidas ao aluno. Reescreva e amplie o texto inserindo a logica causal por tras da regra ("por que a norma funciona assim"), falas naturais prontas para leitura em voz alta e exemplos numericos ou operacionais concretos.
  - **Linguagem Literal e Direta:** Elimine jargoes vazios e construcoes passivas. Use frases curtas com estrutura de causa e efeito ("A finalidade e X? A regra e Y").
  - **Ancoragem em Metafora Fisica:** Se o rascunho nao possuir analogia ou trouxer uma comparacao fraca, crie ou aprimore uma analogia concreta do mundo fisico (ex: praca de pedagio, catraca, balde, filtro) onde a acao fisica corresponda exatamente ao fato gerador e a variacao do elemento corresponda a mudanca de aliquota ou regra.

### Etapa 3: Estruturacao do Roteiro de Aula em 5 Blocos

Entregue o roteiro aprimorado e pronto para gravacao seguindo estritamente esta sequencia estrutural, separando as marcacoes de `[Acao na Lousa - Wacom One / Goodnotes]` do texto integral de `[Locucao Direta]`:

#### 1\. Abertura Instigante (Destruicao de Mito)

  - **Objetivo:** Capturar a atencao nos primeiros 30 segundos quebrando uma falsa crenca comum entre os candidatos.
  - **Execucao:** Escreva a fala completa em primeira pessoa dirigindo-se diretamente ao aluno. Apresente a armadilha que a banca usa para induzir ao erro e declare a regra matriz que governa o tema (ex: finalidade sobre titularidade, substancia sobre forma).

#### 2\. Metafora Central de Fixacao (Locucao + Desenho na Lousa)

  - **Objetivo:** Criar um modelo mental visual que impeca o aluno de esquecer o fato gerador.
  - **Execucao:**
      - Indique exatamente o que desenhar na tela do Goodnotes com a Wacom One (um esquema simples de 2 ou 3 elementos).
      - Redija a fala completa conectando cada parte do desenho ao conceito tecnico (o que ativa a cobranca/regra, por que a tarifa muda e por que manter a posicao parada nao aciona novo evento).

#### 3\. Conteudo Tecnico e Roteiro Visual (Lousa em Estrutura Linear)

  - **Objetivo:** Entregar todas as regras, aliquotas ou classificacoes em uma lista enumerada limpa na lousa, acompanhada de explicacao verbal densa e exemplificada.
  - **Execucao:**
      - Indique o titulo central a ser escrito na lousa.
      - Liste os itens numerados (1, 2, 3, 4...) do mais relevante/oneroso para o mais especifico/isento.
      - Em cada item, redija a fala completa explicando a regra exata, inserindo exemplos praticos do mercado real (valores, prazos, ativos) e fechando o topico com uma pergunta-gatilho rapida e sua resposta imediata.

#### 4\. Alerta de Prova e Pegadinha da Banca (Locucao Focada)

  - **Objetivo:** Blindar o aluno contra a redacao maliciosa dos enunciados de certificacao.
  - **Execucao:** Simule verbalmente uma frase tipica de enunciado de prova que contem um distrator classico. Explique o raciocinio ansioso que faz a maioria errar e forneca a regra de bolso definitiva para desarmar a pegadinha em segundos.

#### 5\. Resolucao Rapida de Fixacao (Cenarios Comparativos na Lousa)

  - **Objetivo:** Consolidar a diferenca pratica atraves do contraste imediato entre dois casos reais.
  - **Execucao:**
      - Indique a divisao da lousa em **Cenario 1** e **Cenario 2**.
      - Construa dois casos curtos com instituicoes, ativos e objetivos reais do mercado financeiro que parecam semelhantes, mas caiam em regras/aliquotas diferentes, detalhando a fala passo a passo.
      - Feche o bloco reforcando o momento exato do fato gerador e o responsavel operacional pelo recolhimento ou execucao nos dois cenarios.

### Etapa 4: Validacao Final e Classificacao do Nivel de Adequacao e Aprendizado

Obrigatoriamente antes de encerrar a entrega, audite o roteiro finalizado e apresente um bloco de **Validacao e Classificacao Pos-Edicao** contendo:

1.  **Veredito de Validacao Tecnica:** Confirmacao de que todas as aliquotas, prazos, fatos geradores e normas citadas no roteiro final estao vigentes e isentos de ambiguidades.
2.  **Resumo de Melhorias Aplicadas:** Lista objetiva das informacoes, falas, exemplos praticos e analogias que foram adicionados ou reescritos para suprir lacunas do material original.
3.  **Classificacao do Nivel de Adequacao e Aprendizado:** Nota global (0 a 10) e selo de classificacao (*Insuficiente*, *Adequado com Ressalvas* ou *Alta Performance - Pronto para Gravacao*), avaliando individualmente:
      - **Precisao Normativa e Tecnica:** Exatidao regulatoria e terminologica.
      - **Completude Explicativa:** Profundidade didatica e ausencia de lacunas conceituais.
      - **Qualidade das Analogias e Exemplos:** Eficacia da metafora visual e clareza dos casos praticos inseridos.
      - **Potencial de Retencao e Foco em Prova:** Fluidez da locucao direta, estrutura linear na lousa e blindagem contra pegadinhas.

## Gotchas

  - **Nunca entregue roteiros rasos ou incompletos:** Se o insumo enviado pelo usuario for curto, esquematico ou sem analogias, e sua obrigacao expandir o texto com falas completas, exemplos e metaforas antes de entregar.
  - **Nao omita a classificacao final:** Toda entrega deve terminar obrigatoriamente com o bloco da Etapa 4 validando as informacoes e classificando o nivel de adequacao e aprendizado do roteiro editado.
  - **Nao mencione ferramentas fora do fluxo do usuario:** Utilize sempre referencias de lousa digital (Wacom One / Goodnotes) e locucao direta; evite sugerir ferramentas ou hardwares que o usuario nao utiliza quando o foco for gravacao em lousa.
  - **Nao pule a validacao normativa:** Se o rascunho do usuario contiver uma aliquota ou prazo desatualizado, corrija-o explicitamente no inicio antes de roteirizar a aula.
  - **Evite sobrecarga visual na lousa:** Enquanto a `[Locucao Direta]` deve ser completa, rica e explicativa, as instrucoes de `[Acao na Lousa]` devem continuar esquematicas e rapidas de desenhar ao vivo enquanto se fala.
  - **Mantenha a precisao terminologica:** Simplificar a didatica nunca significa afrouxar o conceito tecnico (ex: nunca confunda isencao com aliquota zero, nem fato gerador com base de calculo).